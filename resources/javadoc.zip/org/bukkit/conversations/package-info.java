/**
 * Classes dedicated to facilitate direct player-to-plugin communication.
 */
package org.bukkit.conversations;

